from kiteconnect import KiteConnect, KiteTicker
import json
from pathlib import Path
from datetime import datetime, date
import pandas as pd


def user_credentials():
    with open('user.json', 'r') as f:
        login_credential = json.load(f)
    return login_credential


def get_access_token():
    for attempt_no in range(2):
        try:
            with open('accesstoken.json', 'r') as f:
                i = json.load(f)
                access_token = i[f"apikey_{date.today()}"]
                return access_token
        except KeyError:
            if attempt_no < 1:
                login_zerodha()
            else:
                raise Exception


def login_zerodha():
    with open('accesstoken.json', 'r') as f:
        i = json.load(f)

    credentials = user_credentials()
    kite = KiteConnect(api_key=credentials["api_key"])
    try:
        print('click URL to generate request token', kite.login_url())
        request_token = input("copy paste the request token here :")

        new_session = kite.generate_session(
            request_token=request_token, api_secret=credentials['api_secret'])

        access_token = new_session['access_token']

        kite.set_access_token(access_token)
        i = {f"apikey_{date.today()}": access_token}
        data = json.dumps(i)
        Path("accesstoken.json").write_text(data)

    except Exception as e:
        print(e)


access_token = get_access_token()
credentials = user_credentials()


kite = KiteConnect(credentials['api_key'])
i = pd.DataFrame(kite.instruments('NFO'))
# instruments = i[0:190]
# instruments.to_csv('instruments.txt', index=False, sep="\t")
x = i.loc[(i['name'] == 'NIFTY')]
print(x)
