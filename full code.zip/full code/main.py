from datetime import date, datetime
from kiteconnect import KiteConnect
import time
from kiteconnect import KiteTicker
from basiccode import get_access_token, user_credentials, login_zerodha

access_token = get_access_token()
credentials = user_credentials()
kws = KiteTicker(credentials["api_key"], access_token)

tokens = [58929927, 60098567, 58843911]
dict = {58929927: 'SILVERMIC22FEBFUT',
        60098567: 'GOLDM22MARFUT', 58843911: 'SILVERM22APRFUT'}

live_data = {}


def on_ticks(ws, ticks):

    for stock in ticks:
        i = stock['exchange_timestamp']
        lp = stock['last_price']
        live_data[dict[stock['instrument_token']]] = {
            "LTP": lp, "timestamp": i}

    print(live_data)


def on_connect(ws, response):
    print('connected. subscribing tokens')
    ws.subscribe(tokens)
    ws.set_mode(ws.MODE_FULL, tokens)


def stop_ticker():
    print("closing session")
    kws.close(1000, 'Manual close')


kws.on_ticks = on_ticks
kws.on_connect = on_connect
kws.connect(threaded=True)
time.sleep(10)
print("ending")
print(live_data)


stop_ticker()
