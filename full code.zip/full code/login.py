from kiteconnect import KiteConnect, KiteTicker
import json
import pandas as pd
import datetime
import dateutil.parser
from datetime import date, datetime, timedelta
import time
import logging
import threading
from pathlib import Path


minutes_processed = {}
minute_candlesticks = []
current_tick = None
previous_tick = None
tokens = [58929927, 5633]


def user_credentials():
    with open('user.json', 'r') as f:
        login_credential = json.load(f)
    return login_credential


def login_zerodha():
    credentials = user_credentials()
    kite = KiteConnect(api_key=credentials["api_key"])
    try:
        print('click URL to generate request token', kite.login_url())
        request_token = input("copy paste the request token here :")

        new_session = kite.generate_session(
            request_token=request_token, api_secret=credentials['api_secret'])

        access_token = new_session['access_token']

        kite.set_access_token(access_token)
        Path("accesstoken.json").write_text(json.dumps(access_token))

    except Exception:
        print("error")


def login_zerodha():
    credentials = user_credentials()
    kite = KiteConnect(api_key=credentials["api_key"])
    try:
        print('click URL to generate request token', kite.login_url())
        request_token = input("copy paste the request token here :")

        new_session = kite.generate_session(
            request_token=request_token, api_secret=credentials['api_secret'])

        access_token = new_session['access_token']

        kite.set_access_token(access_token)
        return access_token
    except Exception:
        print("error")


def start_ticker():
    credentials = user_credentials
    kws = KiteTicker(api_key='2rbox8q7zjs1f2k4',
                     access_token='skDb37Nb3Dzqps2w3Bpsb5wEtWe8tDtA')
    ticker.on_ticks = on_ticks
    ticker.on_connect = on_connect
    ticker.connect(threaded=True)
    time.sleep(1)
    time.sleep(20)
    stop_ticker
    print("ticker stopped")


def on_ticks(ws, ticks):
    for tick in ticks:
        i = tokens(tick['instrument_token'])
        symbol = i['trading_symbol']
    logging.info('tick:%s CMP = %f', symbol, tick['last_price'])


def on_connect(ws, response):
    ws.subscribe(tokens)


def stop_ticker():
    logging.info('ticker: stopping..')
    ticker.close(1000, "Manual Close")


login_zerodha()
