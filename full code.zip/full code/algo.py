import logging
from kiteconnect import KiteTicker
import time

kws = KiteTicker("2rbox8q7zjs1f2k4", "skDb37Nb3Dzqps2w3Bpsb5wEtWe8tDtA")
tokens = [58929927, 53520391, 54123271]
dict = {58929927: 'SILVERMIC22FEBFUT'}


def on_ticks(ws, ticks):
    logging.debug("Ticks: {}".format(ticks))


def on_connect(ws, response):
    # Callback on successful connect.
    # Subscribe to a list of instrument_tokens (RELIANCE and ACC here).
    print('connected. Subscribing tokens')
    ws.subscribe([58929927])

    # Set SILVER to tick in `full` mode.
    ws.set_mode(ws.MODE_LTP, [58929927])


def on_close(ws, code, reason):
    # On connection close stop the event loop.
    # Reconnection will not happen after executing `ws.stop()`
    ws.stop()


# Assign the callbacks.
kws.on_ticks = on_ticks
kws.on_connect = on_connect
kws.on_close = on_close

# Infinite loop on the main thread. Nothing after this will run.
# You have to use the pre-defined callbacks to manage subscriptions.
kws.connect(threaded=True)
# time.sleep(1)
# i = 0
# while True:
#     i += 1
#     if(i % 2 == 0):
#         if kws.is_connected():
#             kws.set_mode(kws.MODE_LTP, tokens)
#         else:
#             if kws.is_connected():
#                 kws.set_mode(kws.MODE_LTP, tokens)
#         time.sleep(0.1)
#     if i == 20:
#         break
global live_data
ticks = {"stock name": dict[ticks[0]['instrument_token']],
         "timestamp": ticks[0]
         ['exchange_timestamp'],
         "LTP": ticks[0]['last_price']}
