from kiteconnect import KiteTicker, KiteConnect
from login import user_credentials
import datetime
import time
import json

credentials = user_credentials()
kws = KiteTicker(api_key=credentials['api_key'],
                 access_token=kite.access_token)


token_to_instrument = {738561: "RELIANCE",
                       5633: "ACC"}

live_data = {}


def on_ticks(ws, ticks):
    for stock in ticks:
        live_data[token_to_instrument[stock['instrument_token']]] = {"High": stock["ohlc"]["high"],
                                                                     "Low": stock["ohlc"]["low"],
                                                                     "LTP": stock["last_price"]}


def on_connect(ws, response):
    ws.subscribe(list(token_to_instrument.keys()))
    ws.set_mode(ws.MODE_LTP, list(token_to_instrument.keys()))


kws.on_ticks = on_ticks
kws.on_connect = on_connect
kws.connect(threaded=True)
